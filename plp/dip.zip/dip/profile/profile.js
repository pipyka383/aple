function loadProfile() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userName = localStorage.getItem('userName') || 'Пользователь';
    const userEmail = localStorage.getItem('userEmail') || '';
    
    if (!isLoggedIn) {
        window.location.href = '../login/login.html';
        return;
    }
    
    document.getElementById('profileUserName').innerText = userName;
    document.getElementById('profileUserEmail').innerText = userEmail;
    
    const authDiv = document.getElementById('authButtons');
    if (authDiv) {
        authDiv.innerHTML = `<a href="profile.html" class="profile-nav-btn">
            <span class="profile-avatar-svg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="7" r="3.5" stroke="white" stroke-width="1.5" fill="none"/>
                    <path d="M5 19C5 15 8 13 12 13C16 13 19 15 19 19" stroke="white" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                </svg>
            </span>
            <span class="profile-name">${userName}</span>
        </a>`;
    }
    
    loadOrders();
}

function loadOrders() {
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    const ordersEmpty = document.getElementById('ordersEmpty');
    const ordersList = document.getElementById('ordersList');
    
    if (orders.length === 0) {
        ordersEmpty.style.display = 'block';
        ordersList.style.display = 'none';
        return;
    }
    
    ordersEmpty.style.display = 'none';
    ordersList.style.display = 'flex';
    
    ordersList.innerHTML = orders.map(order => `
        <div class="order-card">
            <div class="order-header">
                <span class="order-id">Заказ #${order.id}</span>
                <span class="order-date">${formatDate(order.date)}</span>
            </div>
            <div class="order-items">
                ${order.items.map(item => `
                    <div class="order-item">
                        <div>
                            <div class="order-item-name">${item.name}</div>
                            <div class="order-item-color">Цвет: ${item.color}</div>
                            <div class="order-item-quantity">Количество: ${item.quantity}</div>
                        </div>
                        <div class="order-item-price">$${item.price * item.quantity}</div>
                    </div>
                `).join('')}
            </div>
            <div class="order-footer">
                <span class="order-total-label">Итог:</span>
                <span class="order-total">$${order.total.toFixed(2)}</span>
            </div>
        </div>
    `).join('');
}

function formatDate(dateStr) {
    // Преобразуем дату из формата "17.05.2026, 17:53:43" в нужный вид
    if (dateStr.includes(',')) {
        const [date, time] = dateStr.split(', ');
        return `${date}, ${time}`;
    }
    return dateStr;
}

function logout() {
    localStorage.removeItem('isLoggedIn');
    localStorage.removeItem('userEmail');
    localStorage.removeItem('userName');
    window.location.href = '../index.html';
}

document.getElementById('logoutBtn')?.addEventListener('click', logout);

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const total = cart.reduce((sum, item) => sum + item.quantity, 0);
    const span = document.getElementById('cartCount');
    if (span) span.innerText = total;
}

document.addEventListener('DOMContentLoaded', () => {
    loadProfile();
    updateCartCount();
});