const urlParams = new URLSearchParams(window.location.search);
const productId = parseInt(urlParams.get('id'));

function loadProduct() {
    const product = products.find(p => p.id === productId);
    if (!product) {
        document.getElementById('app').innerHTML = '<div class="container"><p>Товар не найден</p><a href="../index.html">Вернуться в магазин</a></div>';
        return;
    }
    
    const app = document.getElementById('app');
    
    const colorButtons = product.colors.map(color => `
        <button class="color-btn" data-color="${color}">${color}</button>
    `).join('');
    
    // Характеристики БЕЗ эмодзи
    const specsHtml = product.specs.map(spec => `<li>${spec}</li>`).join('');
    
    app.innerHTML = `
        <div class="product-page">
            <div class="container">
                <a href="../index.html" class="back-btn">← Назад</a>
                
                <div class="product-detail-row">
                    <div class="product-emoji-box">
                        <div class="product-emoji" id="productEmoji">${product.emoji}</div>
                    </div>
                    <div class="product-info">
                        <div class="product-category">${product.category}</div>
                        <div class="product-name">${product.name}</div>
                        <div class="product-price">$${product.price}</div>
                        <div class="product-description">${product.description}</div>
                        
                        <div class="colors-title">Цвет:</div>
                        <div class="color-list" id="colorList">
                            ${colorButtons}
                        </div>
                        
                        <button class="add-to-cart-btn" id="addToCartBtn">Добавить в корзину</button>
                    </div>
                </div>
                
                <div class="specs-section">
                    <h3>Основные характеристики</h3>
                    <ul>${specsHtml}</ul>
                </div>
            </div>
        </div>
    `;
    
    let selectedColor = product.colors[0] || '';
    highlightSelectedColor(selectedColor);
    
    document.querySelectorAll('.color-btn').forEach(btn => {
        btn.addEventListener('click', () => {
            selectedColor = btn.getAttribute('data-color');
            highlightSelectedColor(selectedColor);
            const emoji = document.getElementById('productEmoji');
            emoji.style.transform = 'scale(1.1)';
            setTimeout(() => emoji.style.transform = 'scale(1)', 200);
        });
    });
    
    document.getElementById('addToCartBtn')?.addEventListener('click', () => {
        addToCart(product.id, selectedColor);
    });
}

function highlightSelectedColor(selected) {
    document.querySelectorAll('.color-btn').forEach(btn => {
        if (btn.getAttribute('data-color') === selected) {
            btn.classList.add('active');
        } else {
            btn.classList.remove('active');
        }
    });
}

function addToCart(productId, selectedColor) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];
    const product = products.find(p => p.id === productId);
    const existing = cart.find(item => item.id === productId && item.color === selectedColor);
    
    if (existing) {
        existing.quantity++;
    } else {
        cart.push({ ...product, quantity: 1, color: selectedColor });
    }
    
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartCount();
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const total = cart.reduce((sum, item) => sum + item.quantity, 0);
    const span = document.getElementById('cartCount');
    if (span) span.innerText = total;
}

function updateAuthButtons() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userName = localStorage.getItem('userName') || '';
    const authDiv = document.getElementById('authButtons');
    
    if (!authDiv) return;
    
    if (isLoggedIn && userName) {
        authDiv.innerHTML = `<a href="../profile/profile.html" class="profile-nav-btn">
            <span class="profile-avatar-svg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="7" r="3.5" stroke="white" stroke-width="1.5" fill="none"/>
                    <path d="M5 19C5 15 8 13 12 13C16 13 19 15 19 19" stroke="white" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                </svg>
            </span>
            <span class="profile-name">${userName}</span>
        </a>`;
    } else {
        authDiv.innerHTML = `<a href="../login/login.html" class="login-btn">Войти</a>`;
    }
}

function openSearch() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) {
        overlay.classList.add('open');
        document.getElementById('searchInput')?.focus();
    }
}

function closeSearch() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) {
        overlay.classList.remove('open');
    }
    const input = document.getElementById('searchInput');
    if (input) input.value = '';
}

function searchProducts() {
    const query = document.getElementById('searchInput').value.toLowerCase().trim();
    if (query.length > 0) {
        window.location.href = `../index.html?search=${encodeURIComponent(query)}`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    loadProduct();
    updateCartCount();
    updateAuthButtons();
    
    const searchBtn = document.getElementById('searchIconBtn');
    const searchClose = document.getElementById('searchCloseBtn');
    const searchInput = document.getElementById('searchInput');
    
    if (searchBtn) searchBtn.addEventListener('click', openSearch);
    if (searchClose) searchClose.addEventListener('click', closeSearch);
    if (searchInput) searchInput.addEventListener('keypress', (e) => {
        if (e.key === 'Enter') searchProducts();
    });
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeSearch();
    });
});