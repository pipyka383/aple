document.getElementById('loginForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const email = document.getElementById('email').value.trim();
    const password = document.getElementById('password').value;
    
    const savedEmail = localStorage.getItem('userEmail');
    
    if (savedEmail && savedEmail === email) {
        localStorage.setItem('isLoggedIn', 'true');
        window.location.href = '../index.html';
    } else if (email && password) {
        localStorage.setItem('isLoggedIn', 'true');
        localStorage.setItem('userEmail', email);
        localStorage.setItem('userName', email.split('@')[0] || 'Пользователь');
        window.location.href = '../index.html';
    }
});

document.getElementById('registerLink')?.addEventListener('click', (e) => {
    e.preventDefault();
    window.location.href = 'register.html';
});

function updateAuthButtons() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userName = localStorage.getItem('userName') || '';
    const authDiv = document.getElementById('authButtons');
    
    if (!authDiv) return;
    
    if (isLoggedIn && userName) {
        authDiv.innerHTML = `<a href="../profile/profile.html" class="profile-nav-btn">
            <span class="profile-avatar-svg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="7" r="3.5" stroke="white" stroke-width="1.5" fill="none"/>
                    <path d="M5 19C5 15 8 13 12 13C16 13 19 15 19 19" stroke="white" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                </svg>
            </span>
            <span class="profile-name">${userName}</span>
        </a>`;
    } else {
        authDiv.innerHTML = `<a href="login.html" class="login-btn">Войти</a>`;
    }
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const total = cart.reduce((sum, item) => sum + item.quantity, 0);
    const span = document.getElementById('cartCount');
    if (span) span.innerText = total;
}

document.addEventListener('DOMContentLoaded', () => {
    updateCartCount();
    updateAuthButtons();
});