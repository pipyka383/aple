// cart.js — страница корзины

let cart = JSON.parse(localStorage.getItem('cart')) || [];

function saveCart() {
    localStorage.setItem('cart', JSON.stringify(cart));
    updateCartDisplay();
}

function updateCartDisplay() {
    const cartEmpty = document.getElementById('cartEmpty');
    const cartFull = document.getElementById('cartFull');
    const cartItemsContainer = document.getElementById('cartItems');
    const cartItemsCountSpan = document.getElementById('cartItemsCount');
    const cartCountSpan = document.getElementById('cartCount');
    const totalSpan = document.getElementById('total');
    
    const totalItems = cart.reduce((sum, item) => sum + item.quantity, 0);
    
    if (cart.length === 0) {
        cartEmpty.style.display = 'block';
        cartFull.style.display = 'none';
        if (cartCountSpan) cartCountSpan.innerText = '0';
        if (cartItemsCountSpan) cartItemsCountSpan.innerText = '0 товаров';
        return;
    }
    
    cartEmpty.style.display = 'none';
    cartFull.style.display = 'block';
    
    if (cartCountSpan) cartCountSpan.innerText = totalItems;
    
    let itemsText = 'товаров';
    if (totalItems === 1) itemsText = 'товар';
    else if (totalItems >= 2 && totalItems <= 4) itemsText = 'товара';
    if (cartItemsCountSpan) cartItemsCountSpan.innerText = `${totalItems} ${itemsText}`;
    
    cartItemsContainer.innerHTML = cart.map(item => `
        <div class="cart-item-card" data-id="${item.id}" data-color="${item.color}">
            <div class="cart-item-top">
                <div class="cart-item-image">${item.emoji}</div>
                <div class="cart-item-info">
                    <div class="cart-item-name">${item.name}</div>
                    <div class="cart-item-color">Цвет: ${item.color}</div>
                    <div class="cart-item-price">$${item.price}</div>
                </div>
                <button class="cart-item-remove">✕</button>
            </div>
            <div class="cart-item-bottom">
                <div class="cart-item-quantity">
                    <button class="qty-minus">−</button>
                    <span>${item.quantity}</span>
                    <button class="qty-plus">+</button>
                </div>
            </div>
        </div>
    `).join('');
    
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    totalSpan.innerText = `$${subtotal.toFixed(2)}`;
    
    document.querySelectorAll('.cart-item-card').forEach(card => {
        const id = parseInt(card.dataset.id);
        const color = card.dataset.color;
        const product = cart.find(p => p.id === id && p.color === color);
        
        card.querySelector('.qty-plus')?.addEventListener('click', (e) => {
            e.stopPropagation();
            product.quantity++;
            saveCart();
        });
        
        card.querySelector('.qty-minus')?.addEventListener('click', (e) => {
            e.stopPropagation();
            if (product.quantity > 1) {
                product.quantity--;
                saveCart();
            }
        });
        
        card.querySelector('.cart-item-remove')?.addEventListener('click', (e) => {
            e.stopPropagation();
            cart = cart.filter(p => !(p.id === id && p.color === color));
            saveCart();
        });
    });
    
    updateCheckoutButton();
}

function updateCheckoutButton() {
    const checkoutBtn = document.getElementById('checkoutBtn');
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    
    if (!checkoutBtn) return;
    
    if (isLoggedIn) {
        checkoutBtn.textContent = 'Оформить заказ';
        checkoutBtn.style.backgroundColor = '#1d1d1f';
    } else {
        checkoutBtn.textContent = 'Войти для оформления';
        checkoutBtn.style.backgroundColor = '#0071e3';
    }
}

document.getElementById('clearCartBtn')?.addEventListener('click', () => {
    cart = [];
    saveCart();
});

document.getElementById('checkoutBtn')?.addEventListener('click', () => {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    
    if (!isLoggedIn) {
        window.location.href = '../login/login.html';
        return;
    }
    
    if (cart.length === 0) return;
    
    const orders = JSON.parse(localStorage.getItem('orders')) || [];
    const subtotal = cart.reduce((sum, item) => sum + (item.price * item.quantity), 0);
    const tax = subtotal * 0.1;
    const total = subtotal + tax;
    
    const newOrder = {
        id: Date.now(),
        date: new Date().toLocaleString('ru-RU'),
        items: [...cart],
        subtotal: subtotal,
        tax: tax,
        total: total,
        status: 'Обрабатывается'
    };
    
    orders.unshift(newOrder);
    localStorage.setItem('orders', JSON.stringify(orders));
    
    cart = [];
    saveCart();
    
    window.location.href = '../profile/profile.html';
});

function updateAuthButtons() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userName = localStorage.getItem('userName') || '';
    const authDiv = document.getElementById('authButtons');
    
    if (!authDiv) return;
    
    if (isLoggedIn && userName) {
        authDiv.innerHTML = `<a href="../profile/profile.html" class="profile-nav-btn">
            <span class="profile-avatar-svg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="7" r="3.5" stroke="white" stroke-width="1.5" fill="none"/>
                    <path d="M5 19C5 15 8 13 12 13C16 13 19 15 19 19" stroke="white" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                </svg>
            </span>
            <span class="profile-name">${userName}</span>
        </a>`;
    } else {
        authDiv.innerHTML = `<a href="../login/login.html" class="login-btn">Войти</a>`;
    }
}

document.addEventListener('DOMContentLoaded', () => {
    updateCartDisplay();
    updateAuthButtons();
});

window.addEventListener('storage', () => {
    updateCheckoutButton();
    updateAuthButtons();
});