let currentProducts = [...products];

function updateAuthButtons() {
    const isLoggedIn = localStorage.getItem('isLoggedIn') === 'true';
    const userName = localStorage.getItem('userName') || '';
    const authDiv = document.getElementById('authButtons');
    
    if (!authDiv) return;
    
    if (isLoggedIn && userName) {
        authDiv.innerHTML = `<a href="profile/profile.html" class="profile-nav-btn">
            <span class="profile-avatar-svg">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
                    <circle cx="12" cy="7" r="3.5" stroke="white" stroke-width="1.5" fill="none"/>
                    <path d="M5 19C5 15 8 13 12 13C16 13 19 15 19 19" stroke="white" stroke-width="1.5" stroke-linecap="round" fill="none"/>
                </svg>
            </span>
            <span class="profile-name">${userName}</span>
        </a>`;
    } else {
        authDiv.innerHTML = `<a href="login/login.html" class="login-btn">Войти</a>`;
    }
}

function renderHomePage() {
    const app = document.getElementById('app');
    app.innerHTML = `
        <section class="hero">
            <h1>Почувствуйте будущее технологий</h1>
            <p>С нашей премиальной коллекцией устройств</p>
        </section>
        <section class="categories">
            <div class="container">
                <h2>Категории</h2>
                <div class="category-list">
                    <div class="category-item active" data-cat="Все">Все</div>
                    <div class="category-item" data-cat="Ноутбуки">Ноутбуки</div>
                    <div class="category-item" data-cat="Смартфоны">Смартфоны</div>
                    <div class="category-item" data-cat="Планшеты">Планшеты</div>
                    <div class="category-item" data-cat="Аудио">Аудио</div>
                    <div class="category-item" data-cat="Носимые устройства">Носимые устройства</div>
                </div>
            </div>
        </section>
        <section class="products">
            <div class="container">
                <h2>Товары</h2>
                <div id="productGrid" class="product-grid"></div>
            </div>
        </section>
    `;
    
    displayProducts(currentProducts);
    
    document.querySelectorAll('.category-item').forEach(btn => {
        btn.addEventListener('click', () => {
            const cat = btn.getAttribute('data-cat');
            document.querySelectorAll('.category-item').forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            
            if (cat === 'Все') {
                currentProducts = [...products];
            } else {
                currentProducts = products.filter(p => p.category === cat);
            }
            displayProducts(currentProducts);
        });
    });
}

function displayProducts(arr) {
    const grid = document.getElementById('productGrid');
    if (!grid) return;
    if (arr.length === 0) {
        grid.innerHTML = '<div class="no-results">Ничего не найдено</div>';
        return;
    }
    grid.innerHTML = arr.map(p => `
        <a href="product/product.html?id=${p.id}" class="product-card-link">
            <div class="product-card">
                <div class="product-image">${p.emoji}</div>
                <div class="product-category">${p.category}</div>
                <div class="product-title">${p.name}</div>
                <div class="product-description">${p.description.substring(0, 70)}...</div>
                <div class="product-price">$${p.price}</div>
            </div>
        </a>
    `).join('');
}

function updateCartCount() {
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    const total = cart.reduce((sum, item) => sum + item.quantity, 0);
    const span = document.getElementById('cartCount');
    if (span) span.innerText = total;
}

function openSearch() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) {
        overlay.classList.add('open');
        document.getElementById('searchInput').focus();
    }
}

function closeSearch() {
    const overlay = document.getElementById('searchOverlay');
    if (overlay) {
        overlay.classList.remove('open');
    }
    const input = document.getElementById('searchInput');
    if (input) input.value = '';
}

function searchProducts() {
    const query = document.getElementById('searchInput').value.toLowerCase().trim();
    if (query === '') {
        currentProducts = [...products];
    } else {
        currentProducts = products.filter(p => 
            p.name.toLowerCase().includes(query) || 
            p.category.toLowerCase().includes(query)
        );
    }
    displayProducts(currentProducts);
    document.querySelectorAll('.category-item').forEach(b => b.classList.remove('active'));
    const allBtn = document.querySelector('.category-item[data-cat="Все"]');
    if (allBtn) allBtn.classList.add('active');
}

document.addEventListener('DOMContentLoaded', () => {
    renderHomePage();
    updateCartCount();
    updateAuthButtons();
    
    const searchIconBtn = document.getElementById('searchIconBtn');
    const searchCloseBtn = document.getElementById('searchCloseBtn');
    const searchInput = document.getElementById('searchInput');
    
    if (searchIconBtn) searchIconBtn.addEventListener('click', openSearch);
    if (searchCloseBtn) searchCloseBtn.addEventListener('click', closeSearch);
    if (searchInput) searchInput.addEventListener('input', searchProducts);
    
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') closeSearch();
    });
});